import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle
} from "@/components/ui/dialog";
import { useToast } from '@/hooks/use-toast';
import { ArrowLeft, EyeOff, Eye, CheckCircle, AlertCircle, Loader2, Music } from 'lucide-react';
import LocalDatabaseService from '@/lib/local-database';
import { Usuario } from '@/types/usuario';
import { findUserByEmail } from '@/hooks/useRegister';

// Configuração do Google OAuth
const GOOGLE_CLIENT_ID = import.meta.env.VITE_GOOGLE_CLIENT_ID;

const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isGoogleLoading, setIsGoogleLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [modalInfo, setModalInfo] = useState<{
    success: boolean;
    title: string;
    message: string;
  }>({ success: false, title: '', message: '' });
  const { toast } = useToast();
  const navigate = useNavigate();

  // Inicializar o banco de dados local se necessário
  useEffect(() => {
    LocalDatabaseService.initializeDatabase();
  }, []);

  const handleGoogleLogin = async () => {
    setIsGoogleLoading(true);
    
    try {
      // Usar a URL atual como URI de redirecionamento
      const currentUrl = new URL(window.location.href);
      const redirectUri = `${currentUrl.protocol}//${currentUrl.host}`;
      
      // Limpar qualquer resíduo de autenticação anterior
      localStorage.removeItem('google_auth_processing');
      localStorage.removeItem('google_auth_error');
      
      // Informar ao usuário que o processo está começando
      toast({
        title: "Autenticação Google",
        description: "Abrindo janela de login do Google..."
      });
      
      // Construir URL de autenticação do Google
      const googleAuthUrl = `https://accounts.google.com/o/oauth2/v2/auth?client_id=${GOOGLE_CLIENT_ID}&redirect_uri=${encodeURIComponent(redirectUri)}&response_type=token&scope=email%20profile`;
      
      // Abrir uma nova janela para a autenticação do Google
      const authWindow = window.open(googleAuthUrl, 'googleAuthWindow', 'width=500,height=600');
      
      // Se a janela não puder ser aberta (bloqueador de pop-ups, etc)
      if (!authWindow) {
        toast({
          variant: "destructive",
          title: "Erro",
          description: "O bloqueador de pop-ups impediu a abertura da janela de autenticação. Por favor, permita pop-ups para este site e tente novamente."
        });
        
        setIsGoogleLoading(false);
        return;
      }
      
      // Criar um intervalo para verificar se a janela foi fechada
      const checkWindowClosed = setInterval(() => {
        if (authWindow.closed) {
          clearInterval(checkWindowClosed);
          setIsGoogleLoading(false);
          
          // Verificar se a autenticação foi bem-sucedida através do localStorage
          // (O GoogleAuthProvider terá processado o token e armazenado informações)
          const googleProcessed = localStorage.getItem('google_auth_processing');
          if (googleProcessed === 'success') {
            localStorage.removeItem('google_auth_processing');
            toast({
              title: "Autenticação bem-sucedida",
              description: "Processando o login..."
            });
            // Redirecionar para o dashboard após login bem-sucedido
            navigate('/dashboard');
          }
        }
      }, 500);
      
    } catch (error: any) {
      console.error('Erro no login com Google:', error);
      
      // Mostrar modal de erro
      setModalInfo({
        success: false,
        title: "Erro na autenticação com Google",
        message: error.message || "Ocorreu um erro ao processar sua solicitação com o Google."
      });
      setShowModal(true);
      setIsGoogleLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      // Verificar se o email e senha foram fornecidos
      if (!email || !password) {
        throw new Error('Por favor, preencha todos os campos');
      }

      // Buscar usuário pelo email
      const users = LocalDatabaseService.findRecords('usuarios', { email });
      
      if (users.length === 0) {
        throw new Error('Usuário não encontrado');
      }

      const user = users[0] as Usuario;
      
      // Verificar a senha
      if (user.senha !== password) {
        throw new Error('Senha incorreta');
      }

      // Verificar se o usuário tem a propriedade ministerios
      if (!user.ministerios || !Array.isArray(user.ministerios)) {
        // Inicializar a propriedade ministerios como array vazio se não existir
        user.ministerios = [];
        LocalDatabaseService.updateRecord('usuarios', user.id, {
          ministerios: []
        });
        
        // Informar ao usuário que ele precisa criar ou ingressar em um ministério
        toast({
          title: "Aviso",
          description: "Para começar a usar o app, crie ou ingresse em um ministério na página de perfil"
        });
      } else if (user.ministerios.length === 0) {
        // Se o usuário já tem a propriedade ministerios, mas está vazia
        toast({
          title: "Aviso",
          description: "Para começar a usar o app, crie ou ingresse em um ministério na página de perfil"
        });
      } else {
        // Verificar se os ministérios do usuário existem no banco de dados
        let ministeriosValidos = 0;
        const db = JSON.parse(localStorage.getItem('praiseapp_database') || '{"ministerios":[]}');
        
        for (const relacao of user.ministerios) {
          const ministerioExiste = db.ministerios.some((m: any) => m.id === relacao.ministerioId);
          if (ministerioExiste) {
            ministeriosValidos++;
          }
        }
        
        if (ministeriosValidos === 0) {
          toast({
            title: "Aviso",
            description: "Não encontramos nenhum ministério válido associado à sua conta. Por favor, crie ou ingresse em um ministério."
          });
        }
      }

      // Salvar dados do usuário no localStorage
      const userData = {
        id: user.id,
        nome: user.nome,
        email: user.email,
        role: user.role || 'member',
        ministerioId: user.ministerioId,
        ministerios: user.ministerios
      };
      
      localStorage.setItem('user', JSON.stringify(userData));
      localStorage.setItem('token', 'jwt-token');
      
      // Inicializar dados de exemplo para aniversariantes
      LocalDatabaseService.initializeWithSampleData();
      
      // Mostrar modal de sucesso
      setModalInfo({
        success: true,
        title: "Login realizado com sucesso!",
        message: `Bem-vindo(a) ${user.nome}! Você será redirecionado para o dashboard em alguns segundos.`
      });
      setShowModal(true);
      
      // Redirecionar para dashboard após 3 segundos
      setTimeout(() => {
        navigate('/dashboard');
      }, 3000);
      
    } catch (error: any) {
      console.error('Erro no login:', error);
      
      // Mostrar modal de erro
      setModalInfo({
        success: false,
        title: "Erro no login",
        message: error.message || 'Ocorreu um erro ao fazer login. Por favor, tente novamente.'
      });
      setShowModal(true);
      
    } finally {
      setIsLoading(false);
    }
  };

  const handleCloseModal = () => {
    setShowModal(false);
    if (modalInfo.success) {
      navigate('/dashboard');
    }
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4 bg-background">
      <div className="w-full max-w-md animate-fade-up">
        <Card className="w-full card-shadow glass-morphism">
          <CardHeader className="space-y-1 text-center">
            <div className="flex justify-center mb-2">
              <Music className="h-12 w-12 text-primary" />
            </div>
            <CardTitle className="text-2xl font-bold">PraiseLord</CardTitle>
            <CardDescription>
              Entre com seu email e senha para acessar o sistema
            </CardDescription>
          </CardHeader>
          <form onSubmit={handleSubmit}>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input 
                  id="email" 
                  type="email" 
                  placeholder="seu.email@exemplo.com" 
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="password">Senha</Label>
                  <Link 
                    to="/recuperar-senha" 
                    className="text-xs text-primary hover:underline"
                  >
                    Esqueceu a senha?
                  </Link>
                </div>
                <div className="relative">
                  <Input 
                    id="password" 
                    type={showPassword ? 'text' : 'password'} 
                    placeholder="••••••••"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    className="absolute right-0 top-0 h-full px-3"
                    onClick={() => setShowPassword(!showPassword)}
                  >
                    {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                  </Button>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex flex-col space-y-4">
              <Button 
                type="submit" 
                className="w-full" 
                disabled={isLoading}
              >
                {isLoading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Entrando...
                  </>
                ) : (
                  'Entrar'
                )}
              </Button>
              
              <div className="relative w-full">
                <div className="absolute inset-0 flex items-center">
                  <span className="w-full border-t" />
                </div>
                <div className="relative flex justify-center text-xs uppercase">
                  <span className="bg-background px-2 text-muted-foreground">
                    Ou continue com
                  </span>
                </div>
              </div>
              
              <Button 
                type="button" 
                variant="outline" 
                className="w-full"
                onClick={handleGoogleLogin}
                disabled={isGoogleLoading}
              >
                {isGoogleLoading ? (
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                ) : (
                  <svg className="mr-2 h-4 w-4" viewBox="0 0 24 24">
                    <path
                      d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                      fill="#4285F4"
                    />
                    <path
                      d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                      fill="#34A853"
                    />
                    <path
                      d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
                      fill="#FBBC05"
                    />
                    <path
                      d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
                      fill="#EA4335"
                    />
                  </svg>
                )}
                Entrar com Google
              </Button>
              
              <p className="text-center text-sm">
                Não tem uma conta?{' '}
                <Link to="/register" className="text-primary hover:underline">
                  Registre-se
                </Link>
              </p>
            </CardFooter>
          </form>
        </Card>
      </div>

      {/* Modal de confirmação */}
      <Dialog open={showModal} onOpenChange={setShowModal}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              {modalInfo.success ? (
                <CheckCircle className="h-5 w-5 text-green-500" />
              ) : (
                <AlertCircle className="h-5 w-5 text-red-500" />
              )}
              {modalInfo.title}
            </DialogTitle>
            <DialogDescription>
              {modalInfo.message}
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="sm:justify-center">
            <Button 
              onClick={handleCloseModal}
              variant={modalInfo.success ? "default" : "outline"}
            >
              {modalInfo.success ? "Ir para Dashboard" : "Fechar"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Login;
