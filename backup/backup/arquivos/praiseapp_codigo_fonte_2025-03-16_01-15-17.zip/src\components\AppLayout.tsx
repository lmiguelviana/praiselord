/**
 * AppLayout.tsx
 * 
 * Componente de layout principal da aplicação
 * Responsável por:
 * - Estrutura base da aplicação com sidebar e área de conteúdo
 * - Integração com o sistema de rotas do React Router
 * - Layout responsivo com adaptações para mobile e desktop
 */

import { Outlet } from 'react-router-dom';
import Sidebar from './Sidebar';

// Componente de layout que envolve todas as páginas protegidas
const AppLayout = () => {
  return (
    // Container principal com altura mínima da tela e fundo padrão
    <div className="min-h-screen bg-background flex">
      {/* Barra lateral de navegação */}
      <Sidebar />
      
      {/* Área principal de conteúdo */}
      <main className="flex-1 md:ml-64 p-6 pt-16 md:pt-6 transition-all duration-300 overflow-x-hidden">
        {/* Renderiza o conteúdo da rota atual */}
        <Outlet />
      </main>
    </div>
  );
};

export default AppLayout;
